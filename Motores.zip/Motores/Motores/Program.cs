﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Motores
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] motor = new double[15];
            double total = 0;
            int opc = 0;
            int posicao = 0;

            do
            {
                Console.Clear();
                Console.WriteLine("-------MENU-------");
                Console.WriteLine("O. Sair");
                Console.WriteLine("1. Lançar Valor");
                Console.WriteLine("2. Mostrar Valores");
                Console.WriteLine("3. Sobre");
                Console.Write("\nEscolha uma Opção: ");
                opc = int.Parse(Console.ReadLine());

                while (opc < 0 || opc > 3)
                {
                    Console.Write("\nOpção Inválida, Digite Novamente: ");
                    opc = int.Parse(Console.ReadLine());
                }
                Console.Clear();

                if (opc == 1)
                {
                    Console.WriteLine("Opção 'Lançar Valor' Selecionda\n");
                    Console.WriteLine("Escolha o Motor (1...15): ");
                    posicao = int.Parse(Console.ReadLine());

                    while (posicao < 1 || posicao > 15)
                    {
                        Console.WriteLine("Escolha o Motor Novamente (1...15): ");
                        posicao = int.Parse(Console.ReadLine());
                    }

                    Console.WriteLine("\nAtribua um Valor Para o Motor {0} (R$): ", posicao);
                    motor[posicao-1] += double.Parse(Console.ReadLine());

                    Console.Write("\nAperte 'ENTER' Para Exibir o Menu ");
                    Console.ReadKey();
                }
                else
                {

                    if (opc == 2)
                    {
                        Console.WriteLine("Opção 'Mostrar Valores' Selecionda\n");
                        Console.WriteLine("\n  MOTORES      VALORES\n");
                        Console.WriteLine("-------------------------");

                        for (posicao = 0; posicao < 15; posicao++)
                        {
                            Console.WriteLine("Motor:{0: 00}  Valor: {1}", posicao+1, motor[posicao].ToString("C"));
                        }

                        total = motor.Sum();

                        Console.WriteLine("-------------------------");
                        Console.WriteLine("\nTotal: {0}", total.ToString("C"));
                        Console.Write("\nAperte 'ENTER' Para Exibir o Menu ");
                        Console.ReadKey();
                    }
                    else
                    {

                        if (opc == 3)
                        {
                            Console.WriteLine("Opção 'Sobre' Selecionda\n");
                            Console.WriteLine("Desenvolvedor: Ronivy de Melo Soares ");
                            Console.WriteLine("Curso: CTA 171 ");
                            Console.WriteLine("Versão: 1.0.1 ");
                            Console.WriteLine("Data: 06/22");

                            Console.Write("\nAperte 'ENTER' Para Exibir o Menu ");
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.WriteLine("Opção 'Sair' Selecionda\n");
                        }
                    }
                }

            } while (opc != 0);
        }
    }
}
